package org.firstinspires.ftc.teamcode.Opmode.Auto;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;

import org.firstinspires.ftc.teamcode.Hardware.HardwareList;
import org.firstinspires.ftc.teamcode.Vision.RedFrameGrabber;
import org.openftc.easyopencv.OpenCvCamera;
import org.openftc.easyopencv.OpenCvCameraRotation;
import org.openftc.easyopencv.OpenCvInternalCamera;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.ElapsedTime;

@Autonomous(name = "RedStone")
public class RedStone extends LinearOpMode{
    OpenCvCamera phoneCam;
    HardwareList robot = new HardwareList();

    private RedFrameGrabber redFrameGrabber;
    public ElapsedTime elapsedTime;
    //private ElapsedTime  runtime = new ElapsedTime();

    private enum POSITION {
        LEFT,
        CENTER,
        RIGHT,
    }

    RedStone.POSITION position;

    @Override

    public void runOpMode() {
        robot.init(hardwareMap);
        int cameraMonitorViewId = hardwareMap.appContext.getResources().getIdentifier("cameraMonitorViewId", "id", hardwareMap.appContext.getPackageName());
        phoneCam = new OpenCvInternalCamera(OpenCvInternalCamera.CameraDirection.BACK, cameraMonitorViewId);

        elapsedTime = new ElapsedTime();
        // start the vision system
        phoneCam.openCameraDevice();
        redFrameGrabber = new RedFrameGrabber();
        phoneCam.setPipeline(redFrameGrabber);
        phoneCam.startStreaming(640, 480, OpenCvCameraRotation.UPRIGHT);

        while (!isStarted()) {
            //set servo positions
            claw(false);
            grabber(false);
            robot.blueGrabber.setPosition(0.25);
            // Left Guide
            if (gamepad1.dpad_right == true) {
                redFrameGrabber.leftGuide += 0.001;
            } else if (gamepad1.dpad_left == true) {
                redFrameGrabber.leftGuide -= 0.001;
            }

            // Mask
            if (gamepad1.dpad_down == true) {
                redFrameGrabber.mask += 0.001;
            } else if (gamepad1.dpad_up == true) {
                redFrameGrabber.mask -= 0.001;
            }

            // Threshold
            if (gamepad2.y) {
                redFrameGrabber.threshold += 0.001;
            } else if (gamepad2.a) {
                redFrameGrabber.threshold -= 0.001;
            }

            //Determines Skystone Position
            if (redFrameGrabber.position == "LEFT") {
                position = RedStone.POSITION.LEFT;
            } else if (redFrameGrabber.position == "MIDDLE") {
                position = RedStone.POSITION.CENTER;
            } else {
                position = RedStone.POSITION.RIGHT;
            }

            //Displays results
            telemetry.addData("Position", position);
            telemetry.addData("Threshold", redFrameGrabber.threshold);
            telemetry.addData("Rect width", redFrameGrabber.rectWidth);

            telemetry.update();
        }

        waitForStart();

        resetEncoders();

        phoneCam.stopStreaming();

        // Move over to stones
        setPosition(-1790,1790,1790,1790);
        delay(1);
        robot.blueGrabber.setPosition(0.5);
        robot.rightFrame.setPosition(0.25);
        robot.leftFrame.setPosition(0.8);

        // Move to and grab the first skystone
        if(position == RedStone.POSITION.CENTER){
            //determined based on starting position
            setPosition(-2085,1115,1115,2085);
            delay(0.5);
        } else if (position == RedStone.POSITION.RIGHT){
            setPosition(-2565,635,635,2565);
            delay(0.5);
        }
        grabStone();


        //reset Encoders to make further positioning easier
        resetEncoders();

        //Move to foundation and place stone
        //move right, then back, then left
        setPosition(242, -242, -242, -242);
        delay(1);
        setPosition(-5410, -4926, -4926, 5410);
        delay(3);
        setPosition(-4926, -5410, -5410, 4926);
        delay(1.5);

        placeStone();
        delay(0.5);
/*
        //Reset encoders
        resetEncoders();

        /* To help increase the accuracy of the alignment/
        //Move back
        setPosition(-7000, -7000, -7000, 7000);
        delay(0.5);

        //Reset encoders
        resetEncoders();

        int bl = 7068, br = 7068, fl = 7068, fr = -7068;
        //Move back
        setPosition(bl, br, fl, fr);
        delay(2);
        grabber(false);
        delay(2);

/*
        bl -= 484;
        br += 484;
        fl += 484;
        fr += 484;

        setPosition(bl, br, fl, fr);
        delay(0.75);
*/
        // Grab second skystone
        //grabStone();
        //delay(0.5);

        //reset Encoders to make further positioning easier
        //resetEncoders();
/*
        //Move to foundation and place stone
        //move right, then back, then left
        setPosition(242, -242, -242, -242);
        delay(1);
        if(position == RedStone.POSITION.LEFT || position == POSITION.CENTER){
            setPosition(-7200, -7684, -7684, 6600);
            delay(2);
            fl = -6980;
            fr = 7904;
            bl = -7904;
            br = -6980;
            setPosition(bl, br, fl, fr);
            delay(2);
        } else {
            setPosition(-5400, -5884, -5884, 5400);
            delay(2);
            fl = -5180;
            fr = 6104;
            bl = -6106;
            br = -5180;
            setPosition(bl, br, fl, fr);
            setPosition(-6104, -5180, -5180, 6104);
            delay(2);
        }


        placeStone();
        delay(0.5);
*/
        resetEncoders();
        //Change encoder values to move left
        int bl = -500, br = 500, fl = 500, fr = 500;
        setPosition(bl, br, fl, fr);
        robot.rightFrame.setPosition(0.85);
        delay(2);
        robot.leftFrame.setPosition(0.8);

        //Change encoder values to move right
        bl += 4000;
        br -= 4000;
        fl -= 4000;
        fr -= 4000;
        setPosition(bl, br, fl, fr);

        //reset encoders and park
        /*
        resetEncoders();
        setPosition(-1000, -1000, -1000, 1000);
        delay(1);
        setPosition(2000, 2000, 2000, -2000);
        */


        //If time permits(both in auto and real life) add a third stone
        /*If auto is working well enough and time is left over, add in moving the foundation
        Placing a third stone is worth more points than scoring the foundation.  We can score the foundation in teleop
        to still get endgame points.  It's worth doing if we can, but a third stone should be handled first.
        Also, to do this I need to lower the servo arm more, so consider this as you go.
        /

        // Move Foundation

        setPosition();
            delay(0.5);
        }

        robot.rightFrame.setPosition(0.25);
        //setPosition();
        delay(1);
        //setPosition();
        robot.rightFrame.setPosition(0.75);
        //setPosition();

            //Output encoder values
            telemetry.addData("Front Left", robot.frontLeft.getCurrentPosition());
            telemetry.addData("Front Right", robot.frontRight.getCurrentPosition());
            telemetry.addData("Back Left", robot.backLeft.getCurrentPosition());
            telemetry.addData("Back Right", robot.backRight.getCurrentPosition());
*/

    while(opModeIsActive()){
        if(isStopRequested() == true)
            requestOpModeStop();
    }
}
    public void delay(double seconds) {
        elapsedTime.reset();
        while (elapsedTime.time() < seconds && opModeIsActive()) ;
    }
    public void claw(boolean lower){
        if (lower == true){
            robot.redClaw.setPosition(0.27);
        } else {
            robot.redClaw.setPosition(0.7);
        }
    }
    public void grabber(boolean close){
        if (close == true){
        robot.redGrabber.setPosition(0.35);
        } else {
        robot.redGrabber.setPosition(0.75);
        }
    }
    public void placeStone(){
        claw(true);
        delay(0.5);
        grabber(false);
        delay(0.5);
        claw(false);
        delay(0.5);
        grabber(true);
    }
    public void grabStone(){
        claw(true);
        delay(0.5);
        grabber(true);
        delay(0.5);
        claw(false);
        delay(0.5);
    }
    public void setPosition(int bl, int br, int fl, int fr) {
        robot.backRight.setPower(0.75);
        robot.backLeft.setPower(0.75);
        robot.frontRight.setPower(0.75);
        robot.frontLeft.setPower(0.75);
        robot.backRight.setTargetPosition(br);
        robot.backLeft.setTargetPosition(bl);
        robot.frontRight.setTargetPosition(fr);
        robot.frontLeft.setTargetPosition(fl);
    }
    public void resetEncoders() {
        robot.backRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        robot.backLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        robot.frontRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        robot.frontLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        setPosition(0, 0, 0, 0);
        robot.backRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        robot.backLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        robot.frontRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        robot.frontLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        delay(0.2);
    }
}