package org.firstinspires.ftc.teamcode.Hardware.Subsystems;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.Hardware.HardwareList;

public class BlueAutoClaw {
    Telemetry telemetry;
    HardwareList robot = new HardwareList();

    public void claw(boolean lower){
        if (lower == true){ //Need to confirm positions
            robot.blueClaw.setPosition(1.0);
        } else {
            robot.blueClaw.setPosition(0.5);
        }
    }
    public void grabber(boolean close){
        if (close == true){ //Need to confirm positions
            robot.blueClaw.setPosition(1.0);
        } else {
            robot.blueClaw.setPosition(0.5);
        }
    }
}
