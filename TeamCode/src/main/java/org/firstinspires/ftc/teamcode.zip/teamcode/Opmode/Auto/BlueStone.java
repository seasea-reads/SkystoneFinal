package org.firstinspires.ftc.teamcode.Opmode.Auto;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;

import org.firstinspires.ftc.teamcode.Hardware.Subsystems.WheelMovement;
import org.firstinspires.ftc.teamcode.Vision.BlueFrameGrabber;
import org.openftc.easyopencv.OpenCvCamera;
import org.openftc.easyopencv.OpenCvCameraRotation;
import org.openftc.easyopencv.OpenCvInternalCamera;

@Disabled
@Autonomous(name = "BlueStone")
public class BlueStone extends WheelMovement {
    OpenCvCamera phoneCam;

    private BlueFrameGrabber blueFrameGrabber;

    private enum POSITION {
        LEFT,
        CENTER,
        RIGHT,
    }

    BlueStone.POSITION position;

    @Override

    public void runOpMode() throws InterruptedException {
        //initialize everything
        super.runOpMode();

        int cameraMonitorViewId = hardwareMap.appContext.getResources().getIdentifier("cameraMonitorViewId", "id", hardwareMap.appContext.getPackageName());
        phoneCam = new OpenCvInternalCamera(OpenCvInternalCamera.CameraDirection.BACK, cameraMonitorViewId);

        // start the vision system
        phoneCam.openCameraDevice();
        blueFrameGrabber = new BlueFrameGrabber();
        phoneCam.setPipeline(blueFrameGrabber);
        phoneCam.startStreaming(640, 480, OpenCvCameraRotation.UPRIGHT);

        while (!isStarted()) {
            //set servo positions
            claw(false);
            grabber(false);
            redGrabber.setPosition(0.75);
            // Left Guide
            if (gamepad1.dpad_right == true) {
                blueFrameGrabber.leftGuide += 0.001;
            } else if (gamepad1.dpad_left == true) {
                blueFrameGrabber.leftGuide -= 0.001;
            }

            // Mask
            if (gamepad1.dpad_down == true) {
                blueFrameGrabber.mask += 0.001;
            } else if (gamepad1.dpad_up == true) {
                blueFrameGrabber.mask -= 0.001;
            }

            // Threshold
            if (gamepad2.y) {
                blueFrameGrabber.threshold += 0.001;
            } else if (gamepad2.a) {
                blueFrameGrabber.threshold -= 0.001;
            }

            //Determines Skystone Position
            if (blueFrameGrabber.position == "LEFT") {
                position = BlueStone.POSITION.LEFT;
            } else if (blueFrameGrabber.position == "MIDDLE") {
                position = BlueStone.POSITION.CENTER;
            } else {
                position = BlueStone.POSITION.RIGHT;
            }

            //Displays results
            telemetry.addData("Position", position);
            telemetry.addData("Threshold", blueFrameGrabber.threshold);
            telemetry.addData("Rect width", blueFrameGrabber.rectWidth);

            telemetry.update();
        }

        waitForStart();

        resetEncoders();

        phoneCam.stopStreaming();

        // Move to and grab the first skystone
        if(position == BlueStone.POSITION.CENTER){
            //determined based on starting position
            moveBackward(0.75, 105, 0);
        } else if (position == BlueStone.POSITION.LEFT){
            moveBackward(0.75, 210, 0);
        }

        // Move over to stones
        moveLeft(0.5, 1500, 0);
        delay(0.15);


        grabStone();
        redGrabber.setPosition(0.35);
        delay(0.25);

        //reset Encoders to make further positioning easier
        //resetEncoders();

        //Move to foundation and place stone
        //move right, then back, then left
        moveRight(0.5, 242, 0);
        delay(0.15);
        moveBackward(0.75, 4600, 0);
        //was 4668
        delay(0.15);

        //resetEncoders();
        moveLeft(0.5, 484, 0);
        delay(0.15);

        placeStone();
        delay(0.15);

        //Move to get the next stone
        moveRight(0.5, 242, 0);
        grabber(true);
        delay(0.25);
        moveForward(0.75, 6200, 0);
        delay(0.25);

        grabber(false);
        blueClaw.setPosition(0.77);
        delay(0.25);

        moveLeft(0.5, 50, 0);
        delay(0.1);

        // Grab second skystone
        grabStone();
        delay(0.25);

        //Move to foundation and place stone
        //move right, then back, then left
        moveRight(0.5, 242, 0);
        delay(0.15);

        //different distance depending on stone position
        if(position == BlueStone.POSITION.LEFT || position == POSITION.CENTER){
            moveBackward(0.75, 5642, 0);
            delay(0.25);
        } else {
            moveBackward(0.75, 5742, 0);;
            delay(0.25);
        }

        moveLeft(0.5, 484, 0);
        delay(0.15);
        leftFrame.setPosition(0.3);


        placeStone();
        delay(0.15);

        //Output encoder values
        telemetry.addData("Front Left", frontLeft.getCurrentPosition());
        telemetry.addData("Front Right", frontRight.getCurrentPosition());
        telemetry.addData("Back Left", backLeft.getCurrentPosition());
        telemetry.addData("Back Right", backRight.getCurrentPosition());
        telemetry.update();


        while(opModeIsActive()){
            if(isStopRequested() == true)
                requestOpModeStop();
        }
    }
    public void claw(boolean lower){
        if (lower == true){
            blueClaw.setPosition(0.77);
        } else {
            blueClaw.setPosition(0.47);
        }
    }
    public void grabber(boolean close){
        if (close == true){
            blueGrabber.setPosition(0.5);
        } else {
            blueGrabber.setPosition(0.25);
        }
    }
    public void placeStone(){
        claw(true);
        delay(0.15);
        grabber(false);
        delay(0.15);
        claw(false);
        delay(0.15);
        grabber(true);
    }
    public void grabStone(){
        claw(true);
        delay(0.3);
        grabber(true);
        delay(0.3);
        claw(false);
        delay(0.25);
    }

}