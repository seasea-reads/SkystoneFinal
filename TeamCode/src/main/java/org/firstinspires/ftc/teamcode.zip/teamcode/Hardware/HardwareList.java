package org.firstinspires.ftc.teamcode.Hardware;


import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

/* The purpose of this class is to declare all motors, servos, and sensors
   in a single location to make identifying them easier in the future */
public class HardwareList {
    /* Declares the four wheels */
    public DcMotor frontLeft = null;
    public DcMotor backLeft = null;
    public DcMotor frontRight = null;
    public DcMotor backRight = null;
    public DcMotor intake = null;
    public DcMotor verticalSlides = null;

    /* Declares the auto claw servos */
    public Servo blueClaw = null;
    public Servo blueGrabber = null;
    public Servo redClaw = null;
    public Servo redGrabber = null;

    /*Declares the main lift servos*/
    public Servo horizontalSlides = null;
    public Servo mainGrabber = null;

    /* Declares the frame grabber servos*/
    public Servo leftFrame = null;
    public Servo rightFrame = null;

    /* Sets servo position */
    public static final double MID_SERVO = 0.5 ;

    /* Declares the local OpMode members */
    HardwareMap hwMap           =  null;

    private ElapsedTime period  = new ElapsedTime();

    /* Initialize the standard Hardware interfaces */
    public void init(HardwareMap rhwMap) {
        /* Save the reference as Hardware map */
        hwMap = rhwMap;

        /* Define and Initialize Drive Motors */
        frontLeft = hwMap.get(DcMotor.class, "FL");
        backLeft = hwMap.get(DcMotor.class, "BL");
        frontRight = hwMap.get(DcMotor.class, "FR");
        backRight = hwMap.get(DcMotor.class, "BR");
        intake = hwMap.get(DcMotor.class, "I");
        verticalSlides = hwMap.get(DcMotor.class, "VS"); //Because we have two sets of verticalSlides


        frontLeft.setDirection(DcMotor.Direction.FORWARD); //Need to confirm these
        backLeft.setDirection(DcMotor.Direction.FORWARD);
        frontRight.setDirection(DcMotor.Direction.REVERSE);
        backRight.setDirection(DcMotor.Direction.REVERSE);

        /* Set all motors to zero power */
        frontLeft.setPower(0);
        backLeft.setPower(0);
        frontRight.setPower(0);
        backRight.setPower(0);
        intake.setPower(0);

        /* Set motors to run with encoders*/
        frontLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        backLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        frontRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        backRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        verticalSlides.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        intake.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        /* Define and initialize autonomous servos*/
        blueClaw = hwMap.get(Servo.class, "BC");
        blueClaw.setPosition(0.43);

        blueGrabber = hwMap.get(Servo.class, "BG");
        blueGrabber.setPosition(0.25);

        redClaw = hwMap.get(Servo.class, "RC");
        redClaw.setPosition(0.7);

        redGrabber = hwMap.get(Servo.class, "RG");
        redGrabber.setPosition(0.27);

        leftFrame = hwMap.get(Servo.class, "LFG");
        leftFrame.setPosition(0.75);

        rightFrame = hwMap.get(Servo.class, "RFG");
        rightFrame.setPosition(0.3);
    }
}