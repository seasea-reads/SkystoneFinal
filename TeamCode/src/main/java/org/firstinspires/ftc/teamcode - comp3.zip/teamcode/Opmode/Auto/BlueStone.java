package org.firstinspires.ftc.teamcode.Opmode.Auto;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;

import org.firstinspires.ftc.teamcode.Hardware.Subsystems.WheelMovement;
import org.firstinspires.ftc.teamcode.Vision.BlueFrameGrabber;
import org.openftc.easyopencv.OpenCvCamera;
import org.openftc.easyopencv.OpenCvCameraRotation;
import org.openftc.easyopencv.OpenCvInternalCamera;


@Autonomous(name = "BlueStone")
public class BlueStone extends WheelMovement {
    OpenCvCamera phoneCam;

    private BlueFrameGrabber blueFrameGrabber;

    private enum POSITION {
        LEFT,
        CENTER,
        RIGHT,
    }

    BlueStone.POSITION position;

    @Override

    public void runOpMode() throws InterruptedException {
        //initialize everything
        super.runOpMode();

        int cameraMonitorViewId = hardwareMap.appContext.getResources().getIdentifier("cameraMonitorViewId", "id", hardwareMap.appContext.getPackageName());
        phoneCam = new OpenCvInternalCamera(OpenCvInternalCamera.CameraDirection.BACK, cameraMonitorViewId);

        // start the vision system
        phoneCam.openCameraDevice();
        blueFrameGrabber = new BlueFrameGrabber();
        phoneCam.setPipeline(blueFrameGrabber);
        phoneCam.startStreaming(640, 480, OpenCvCameraRotation.UPRIGHT);

        while (!isStarted()) {
            //set servo positions
            claw(false);
            grabber(false);
            redGrabber.setPosition(0.75);
            // Left Guide
            if (gamepad1.dpad_right == true) {
                blueFrameGrabber.leftGuide += 0.001;
            } else if (gamepad1.dpad_left == true) {
                blueFrameGrabber.leftGuide -= 0.001;
            }

            // Mask
            if (gamepad1.dpad_down == true) {
                blueFrameGrabber.mask += 0.001;
            } else if (gamepad1.dpad_up == true) {
                blueFrameGrabber.mask -= 0.001;
            }

            // Threshold
            if (gamepad2.y) {
                blueFrameGrabber.threshold += 0.001;
            } else if (gamepad2.a) {
                blueFrameGrabber.threshold -= 0.001;
            }

            //Determines Skystone Position
            if (blueFrameGrabber.position == "LEFT") {
                position = BlueStone.POSITION.LEFT;
            } else if (blueFrameGrabber.position == "MIDDLE") {
                position = BlueStone.POSITION.CENTER;
            } else {
                position = BlueStone.POSITION.RIGHT;
            }

            //Displays results
            telemetry.addData("Position", position);
            telemetry.addData("Threshold", blueFrameGrabber.threshold);
            telemetry.addData("Rect width", blueFrameGrabber.rectWidth);

            telemetry.update();
        }

        waitForStart();

        resetEncoders();

        phoneCam.stopStreaming();

        // Move to and grab the first skystone
        moveLeft(0.5, 400, 0);

        // Move over to stones
        blueGrabber.setPosition(0.4);
        blueClaw.setPosition(0.2);

        if(position == BlueStone.POSITION.CENTER){
            //determined based on starting position
            moveBackward(0.75, 80, 0);
        } else if (position == BlueStone.POSITION.LEFT){
            moveBackward(0.75, 155, 0);
        }

        moveLeft(0.5, 1150, 0);
        delay(0.15);


        grabStone();
        redClaw.setPosition(0.35);
        delay(0.25);

        //reset Encoders to make further positioning easier
        //resetEncoders();

        //Move to foundation and place stone
        //move right, then back, then left
        moveRight(0.5, 442, 0);
        delay(0.15);
        if(position == BlueStone.POSITION.LEFT){
            moveBackward(0.75, 4000, 0);
        } else {
            moveBackward(0.75, 4600, 0);
        }
        //was 4668
        delay(0.15);

        //resetEncoders();
        moveLeft(0.5, 484, 0);
        delay(0.15);

        placeStone();
        delay(0.15);

        //Move to get the next stone
        moveRight(0.5, 300, 0);
        claw(true);
        delay(0.25);
        if(position == BlueStone.POSITION.RIGHT){
            moveForward(0.75, 6200, 0);
        } else if(position == BlueStone.POSITION.CENTER){
            moveForward(0.75, 5980, 0);
        } else {
            moveForward(0.75, 5400, 0);
        }
        delay(0.25);

        claw(false);
        //blueClaw.setPosition(0.77);
        delay(0.25);

        blueGrabber.setPosition(0.5);
        blueClaw.setPosition(0.2);

        moveLeft(0.5, 275, 0);
        delay(0.1);

        // Grab second skystone
        grabStone();
        delay(0.25);

        //Move to foundation and place second stone
        //move right, then back, then left
        moveRight(0.5, 457, 0);
        delay(0.15);

        //different distance depending on stone position
        if(position == BlueStone.POSITION.LEFT){
            moveBackward(0.75, 4242, 0); // Drop for left??
            delay(0.25);
        } else if (position == BlueStone.POSITION.RIGHT){
            moveBackward(0.75, 5142, 0);;
            delay(0.25);
        } else{
            moveBackward(0.75, 4942, 0);
        }
        moveLeft(0.75, 500, 0);
        placeStone();
        delay(0.15);

        moveRight(1, 200, 0);

        moveForward(1, 1000, 0);


        //Output encoder values
        telemetry.addData("Front Left", frontLeft.getCurrentPosition());
        telemetry.addData("Front Right", frontRight.getCurrentPosition());
        telemetry.addData("Back Left", backLeft.getCurrentPosition());
        telemetry.addData("Back Right", backRight.getCurrentPosition());
        telemetry.update();

        while(opModeIsActive()){
            if(isStopRequested() == true)
                requestOpModeStop();
        }
    }
    public void claw(boolean close){
        if (close == true){
            blueClaw.setPosition(0.45);
        } else {
            blueClaw.setPosition(0.27);
        }
    }
    public void grabber(boolean lower){
        if (lower == true){
            blueGrabber.setPosition(0.5);
        } else {
            blueGrabber.setPosition(0.2);
        }
    }
    public void grabFoundation(boolean lower){
        if (lower == true) {
            //Lower grabbers
            rightFrame.setPosition(1);
            leftFrame.setPosition(0);
        } else {
            //Raise grabbers
            rightFrame.setPosition(0);
            leftFrame.setPosition(0.9);
        }
    }
    public void placeStone(){
        grabber(true);
        delay(0.15);
        claw(false);
        delay(0.25);
        grabber(false);
        delay(0.15);
        claw(true);
    }
    public void grabStone(){
        grabber(true);
        delay(0.3);
        claw(true);
        delay(0.3);
        grabber(false);
        delay(0.25);
    }

}