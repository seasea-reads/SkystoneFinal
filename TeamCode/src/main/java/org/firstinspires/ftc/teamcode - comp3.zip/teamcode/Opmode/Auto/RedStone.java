package org.firstinspires.ftc.teamcode.Opmode.Auto;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import org.firstinspires.ftc.teamcode.Hardware.Subsystems.WheelMovement;
import org.firstinspires.ftc.teamcode.Vision.RedFrameGrabber;
import org.openftc.easyopencv.OpenCvCamera;
import org.openftc.easyopencv.OpenCvCameraRotation;
import org.openftc.easyopencv.OpenCvInternalCamera;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.ElapsedTime;

@Autonomous(name = "RedStone")
public class RedStone extends WheelMovement {
    OpenCvCamera phoneCam;

    private RedFrameGrabber redFrameGrabber;
    //private ElapsedTime  runtime = new ElapsedTime();

    private enum POSITION {
        LEFT,
        CENTER,
        RIGHT,
    }

    RedStone.POSITION position;

    @Override

    public void runOpMode()  throws InterruptedException {
        //initialize everything
        super.runOpMode();

        int cameraMonitorViewId = hardwareMap.appContext.getResources().getIdentifier("cameraMonitorViewId", "id", hardwareMap.appContext.getPackageName());
        phoneCam = new OpenCvInternalCamera(OpenCvInternalCamera.CameraDirection.BACK, cameraMonitorViewId);

        elapsedTime = new ElapsedTime();
        // start the vision system
        phoneCam.openCameraDevice();
        redFrameGrabber = new RedFrameGrabber();
        phoneCam.setPipeline(redFrameGrabber);
        phoneCam.startStreaming(640, 480, OpenCvCameraRotation.UPRIGHT);

        while (!isStarted()) {
            //set servo positions
            claw(false);
            grabber(false);
            blueGrabber.setPosition(0.2);
            // Left Guide
            if (gamepad1.dpad_right == true) {
                redFrameGrabber.leftGuide += 0.001;
            } else if (gamepad1.dpad_left == true) {
                redFrameGrabber.leftGuide -= 0.001;
            }

            // Mask
            if (gamepad1.dpad_down == true) {
                redFrameGrabber.mask += 0.001;
            } else if (gamepad1.dpad_up == true) {
                redFrameGrabber.mask -= 0.001;
            }

            // Threshold
            if (gamepad2.y) {
                redFrameGrabber.threshold += 0.001;
            } else if (gamepad2.a) {
                redFrameGrabber.threshold -= 0.001;
            }

            //Determines Skystone Position
            if (redFrameGrabber.position == "LEFT") {
                position = RedStone.POSITION.LEFT;
            } else if (redFrameGrabber.position == "MIDDLE") {
                position = RedStone.POSITION.CENTER;
            } else {
                position = RedStone.POSITION.RIGHT;
            }

            //Displays results
            telemetry.addData("Position", position);
            telemetry.addData("Threshold", redFrameGrabber.threshold);
            telemetry.addData("Rect width", redFrameGrabber.rectWidth);

            telemetry.update();
        }

        waitForStart();

        resetEncoders();

        phoneCam.stopStreaming();

        // Move to and grab the first skystone
        moveRight(0.5, 400, 0);

        // Move over to stones
        redGrabber.setPosition(0.4);
        redClaw.setPosition(0.57);

        if(position == RedStone.POSITION.CENTER){
            //determined based on starting position
            moveBackward(0.75, 75, 0);
        } else if (position == RedStone.POSITION.RIGHT){
            moveBackward(0.75, 155, 0);
        }

        moveRight(0.5, 1200, 0);
        delay(0.15);


        grabStone();
        blueClaw.setPosition(0.45);
        delay(0.25);


        //reset Encoders to make further positioning easier
        //resetEncoders();

        //Move to foundation and place stone
        //move right, then back, then left
        moveLeft(0.5, 242, 0);
        delay(0.15);
        if(position == RedStone.POSITION.LEFT){
            moveBackward(0.75, 4000, 0);
        } else {
            moveBackward(0.75, 3800, 0);
        }
        //was 4668
        delay(0.15);

        //resetEncoders();
        moveRight(0.5, 484, 0);
        delay(0.15);

        placeStone();
        delay(0.15);

        //Move to get the next stone
        moveLeft(0.5, 300, 0);
        claw(true);
        delay(0.25);
        if(position == RedStone.POSITION.RIGHT){
            moveForward(0.75, 5200, 0);
        } else if(position == RedStone.POSITION.CENTER){
            moveForward(0.75, 5000, 0);
        } else {
            moveForward(0.75, 5650, 0);
        }
        delay(0.25);

        claw(false);
        //blueClaw.setPosition(0.77);
        delay(0.25);

        redGrabber.setPosition(0.4);
        redClaw.setPosition(0.57);

        moveRight(0.5, 225, 0);
        delay(0.1);

        // Grab second skystone
        grabStone();
        delay(0.25);

        //Move to foundation and place second stone
        //move right, then back, then left
        moveLeft(0.5, 257, 0);
        delay(0.15);

        //different distance depending on stone position
        if(position == RedStone.POSITION.RIGHT){
            moveBackward(0.75, 4642, 0);
            delay(0.25);
        } else if(position == RedStone.POSITION.CENTER){
            moveBackward(0.75, 6000, 0);
            delay(0.25);
        } else {
            moveBackward(0.75, 6642, 0);
            delay(0.25);
        }

        moveRight(0.75, 500, 0);
        placeStone();
        delay(0.15);

        //Re-adjust to be centered on the foundation

        //Move out and turn
        moveLeft(0.75, 250, 0);

        if(position == RedStone.POSITION.CENTER || position == POSITION.RIGHT){
            moveForward(1, 1800, 0);
        }else{
            moveForward(1, 1500, 0);
        }

        //Turn with foundation
        //moveRight(0.5, 200, 0);
        //Release foundation and park


        //Output encoder values
        telemetry.addData("Front Left", frontLeft.getCurrentPosition());
        telemetry.addData("Front Right", frontRight.getCurrentPosition());
        telemetry.addData("Back Left", backLeft.getCurrentPosition());
        telemetry.addData("Back Right", backRight.getCurrentPosition());
        telemetry.update();

        while(opModeIsActive()){
            if(isStopRequested() == true)
                requestOpModeStop();
        }
    }
    public void claw(boolean close){
        if (close == true){
            redClaw.setPosition(0.35);
        } else {
            redClaw.setPosition(0.7);
        }
    }
    public void grabber(boolean lower){
        if (lower == true){
            redGrabber.setPosition(0.3);
        } else {
            redGrabber.setPosition(0.7);
        }
    }
    public void grabFoundation(boolean lower){
        if (lower == true) {
            //Lower grabbers
            rightFrame.setPosition(0.3);
            leftFrame.setPosition(0.9);
        } else {
            //Raise grabbers
            rightFrame.setPosition(0.85);
            leftFrame.setPosition(0.3);
        }
    }
    public void placeStone(){
        grabber(true);
        delay(0.15);
        claw(false);
        delay(0.25);
        grabber(false);
        delay(0.15);
        claw(true);
    }
    public void grabStone(){
        grabber(true);
        delay(0.3);
        claw(true);
        delay(0.3);
        grabber(false);
        delay(0.25);
    }
}